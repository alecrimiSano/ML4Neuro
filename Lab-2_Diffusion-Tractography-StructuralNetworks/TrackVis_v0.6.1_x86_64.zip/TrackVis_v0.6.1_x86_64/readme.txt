Just put trackvis to your bin directory or whereever you want to execute it from. That's it!

NEW: track_vis is a command-line tool that can also visualize fiber tracks.

NOTE: it is recommended to put trackvis to the same directory as diffusion toolkit binaries.

